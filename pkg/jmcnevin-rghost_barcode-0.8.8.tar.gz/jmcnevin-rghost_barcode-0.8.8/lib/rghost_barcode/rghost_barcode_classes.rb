class  RGhost::Barcode::Auspost < RGhost::Barcode::Base
 
end
class  RGhost::Barcode::Azteccode < RGhost::Barcode::Base
 
end
class  RGhost::Barcode::Code11 < RGhost::Barcode::Base
 
end
class  RGhost::Barcode::Code128 < RGhost::Barcode::Base
 
end
class  RGhost::Barcode::Code2of5 < RGhost::Barcode::Base
 
end
class  RGhost::Barcode::Code39 < RGhost::Barcode::Base
 
end
class  RGhost::Barcode::Code93 < RGhost::Barcode::Base
 
end
class  RGhost::Barcode::Datamatrix < RGhost::Barcode::Base
 
end
class  RGhost::Barcode::Ean13 < RGhost::Barcode::Base
 
end
class  RGhost::Barcode::Ean2 < RGhost::Barcode::Base
 
end
class  RGhost::Barcode::Ean5 < RGhost::Barcode::Base
 
end
class  RGhost::Barcode::Ean8 < RGhost::Barcode::Base
 
end
class  RGhost::Barcode::Interleaved2of5 < RGhost::Barcode::Base
 
end
class  RGhost::Barcode::Isbn < RGhost::Barcode::Base
 
end
class  RGhost::Barcode::Kix < RGhost::Barcode::Base
 
end
class  RGhost::Barcode::Maxicode < RGhost::Barcode::Base
 
end
class  RGhost::Barcode::Msi < RGhost::Barcode::Base
 
end
class  RGhost::Barcode::Onecode < RGhost::Barcode::Base
 
end
class  RGhost::Barcode::Pdf417 < RGhost::Barcode::Base
 
end
class  RGhost::Barcode::Pharmacode < RGhost::Barcode::Base
 
end
class  RGhost::Barcode::Plessey < RGhost::Barcode::Base
 
end
class  RGhost::Barcode::Postnet < RGhost::Barcode::Base
 
end
class  RGhost::Barcode::Qrcode < RGhost::Barcode::Base
 
end
class  RGhost::Barcode::Rationalizedcodabar < RGhost::Barcode::Base
 
end
class  RGhost::Barcode::Raw < RGhost::Barcode::Base
 
end
class  RGhost::Barcode::Royalmail < RGhost::Barcode::Base
 
end
class  RGhost::Barcode::Rss14 < RGhost::Barcode::Base
 
end
class  RGhost::Barcode::Rssexpanded < RGhost::Barcode::Base
 
end
class  RGhost::Barcode::Rsslimited < RGhost::Barcode::Base
 
end
class  RGhost::Barcode::Symbol < RGhost::Barcode::Base
 
end
class  RGhost::Barcode::Upca < RGhost::Barcode::Base
 
end
class  RGhost::Barcode::Upce < RGhost::Barcode::Base
 
end
